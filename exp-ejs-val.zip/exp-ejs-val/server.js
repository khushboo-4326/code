const express=require("express")
const {check,validationResult}=require("express-validator")
const app=express();

const path = require('path');
app.use(express.urlencoded({extended: false}))
//app.use(express.json())
//app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

app.get("/",(req,res)=>{
    res.render("form1")
})

app.post("/validate",
    [
        check("username","Username should not be empty").notEmpty(),
        check("password").notEmpty()
    ]
    ,(req,res)=>{
        const errors=validationResult(req); 
        if(!errors.isEmpty())
        {
            console.log(errors)
            res.render("form1",{errors:errors})
            //res.send(errors)
        }  
        else
        {
            res.send(req.body);
        }
        
    })
app.listen(8000)