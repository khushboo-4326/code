const express = require('express');
const path = require('path');
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');

const app = express();

//Tell Express.js where to find your Javascript files.
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: false }));

// view engine setup
app.set('views', 'views');
app.set('view engine', 'pug');
//Mount routers
app.use('/', indexRouter);
app.use('/users', usersRouter);

app.listen(8000);